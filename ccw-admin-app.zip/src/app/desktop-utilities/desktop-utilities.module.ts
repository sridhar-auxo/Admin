import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesktopUtilitiesComponent } from './desktop-utilities.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DesktopUtilitiesComponent]
})
export class DesktopUtilitiesModule { }

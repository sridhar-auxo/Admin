import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-utilities',
  templateUrl: './desktop-utilities.component.html',
  styleUrls: ['./desktop-utilities.component.scss']
})
export class DesktopUtilitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesktopUtilitiesComponent } from './desktop-utilities.component';

describe('DesktopUtilitiesComponent', () => {
  let component: DesktopUtilitiesComponent;
  let fixture: ComponentFixture<DesktopUtilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesktopUtilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesktopUtilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

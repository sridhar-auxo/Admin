import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [
  {
    path: '',redirectTo: 'cloudWorkflow', pathMatch: 'full',
    //children: [
      //{ path: 'cloudAi', loadChildren: './cloud-ai/cloud-ai.module#CloudAiModule' },
      //{ path: 'cloudCapture', loadChildren: './cloud-capture/cloud-capture.module#CloudCaptureModule' },
      //{ path: 'cloudWorkflow', component: 'CloudWorkflowComponent'}
      //{ path: 'desktopUtilities', loadChildren: './desktop-utilities/desktop-utilities.module#DesktopUtilitiesModule' }
    //]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule {}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloudAiComponent } from './cloud-ai.component';

describe('CloudAiComponent', () => {
  let component: CloudAiComponent;
  let fixture: ComponentFixture<CloudAiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloudAiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloudAiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

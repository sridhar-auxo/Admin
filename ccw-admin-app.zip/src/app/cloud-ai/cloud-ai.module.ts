import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CloudAiComponent } from './cloud-ai.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CloudAiComponent]
})
export class CloudAiModule { }

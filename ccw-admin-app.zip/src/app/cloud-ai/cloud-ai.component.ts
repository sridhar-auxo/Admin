import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-ai',
  templateUrl: './cloud-ai.component.html',
  styleUrls: ['./cloud-ai.component.scss']
})
export class CloudAiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

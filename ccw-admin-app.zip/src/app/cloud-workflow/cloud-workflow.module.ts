import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TreeModule } from 'angular-tree-component';
import { CloudWorkflowComponent } from './cloud-workflow.component';
import { CloudWorkflowRoutingModule } from './cloud-workflow-routing.module';
import {DepartmentsModule} from './departments/departments.module'

import { DepartmentSharedQueuesComponent } from './department-shared-queues/department-shared-queues.component';
import { DepartmentUsersComponent } from './department-users/department-users.component';
import { DepartmentsComponent } from './departments/departments.component';
import { SearchComponent } from './search/search.component';
import { SharedQueueDetailsComponent } from './shared-queue-details/shared-queue-details.component';
import { UserDetailsComponent } from './user-details/user-details.component';
//import { DepartmentsEditComponent } from './departments/departments-edit/departments-edit.component';


@NgModule({
  imports: [
    CommonModule,
    CloudWorkflowRoutingModule,
    DepartmentsModule,
    TreeModule
  ],

  declarations: [
    DepartmentsComponent,
    DepartmentUsersComponent,
    DepartmentSharedQueuesComponent,
    SearchComponent,
    SharedQueueDetailsComponent,
    UserDetailsComponent,
    CloudWorkflowComponent
  ],
  entryComponents:[
    //DepartmentsEditComponent
  ]
})
export class CloudWorkflowModule { }

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CloudWorkflowComponent } from './cloud-workflow.component';


const routes: Routes = [
  {
    path: 'cloudWorkflow', component: CloudWorkflowComponent,
    //children: [
    //  {path: '', redirectTo: 'Department', pathMatch: 'full'},
    //  {path: 'Department', component: 'DepartmentsComponent'}
    //
    //]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class CloudWorkflowRoutingModule {}

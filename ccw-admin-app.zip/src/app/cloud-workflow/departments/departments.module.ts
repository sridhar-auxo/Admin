import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TreeModule } from 'angular-tree-component';
//import { DepartmentsEditComponent } from './departments-edit/departments-edit.component';

@NgModule({
  imports: [
    CommonModule,
    TreeModule
  ],
  declarations: [
    //DepartmentsEditComponent
  ],
  //entryComponents:[DepartmentsEditComponent]
})
export class DepartmentsModule { }

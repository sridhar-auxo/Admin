import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DepartmentsEditComponent } from './departments-edit/departments-edit.component';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.scss']
})
export class DepartmentsComponent implements OnInit {

  nodes = [
    {
      id: 1,
      name: 'Amazon Inc.',  isExpanded: true,
      children: [
        { id: 2, name: 'Account Administration' },
        { id: 4, name: 'Business Administration' },
        { id: 5, name: 'Business Analytics' },
        { id: 6, name: 'Project Managers' },
        { id: 7, name: 'Software Designers' },
        { id: 8, name: 'Front End Developers' },
        { id: 9, name: 'Angular Developers' },
        { id: 10, name: 'Backend Developers' },
        { id: 11, name: 'Quality Analytics' },
        { id: 12, name: 'Off Shore Employees' },
      ]
    }
  ];
  options = {
    isExpanded: true,
  }
  constructor(private modalService: NgbModal) { }
  departmentEdit() {
    this.modalService.open(DepartmentsEditComponent);
  }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentSharedQueuesComponent } from './department-shared-queues.component';

describe('DepartmentSharedQueuesComponent', () => {
  let component: DepartmentSharedQueuesComponent;
  let fixture: ComponentFixture<DepartmentSharedQueuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepartmentSharedQueuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepartmentSharedQueuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

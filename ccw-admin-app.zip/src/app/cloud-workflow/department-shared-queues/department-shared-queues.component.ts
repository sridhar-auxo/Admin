import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-shared-queues',
  templateUrl: './department-shared-queues.component.html',
  styleUrls: ['./department-shared-queues.component.scss']
})
export class DepartmentSharedQueuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-users',
  templateUrl: './department-users.component.html',
  styleUrls: ['./department-users.component.scss']
})
export class DepartmentUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

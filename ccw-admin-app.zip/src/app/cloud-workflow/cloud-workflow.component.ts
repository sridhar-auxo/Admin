import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-workflow',
  templateUrl: './cloud-workflow.component.html',
  styleUrls: ['./cloud-workflow.component.scss']
})
export class CloudWorkflowComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}

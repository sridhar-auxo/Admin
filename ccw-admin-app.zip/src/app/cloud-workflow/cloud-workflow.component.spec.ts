import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloudWorkflowComponent } from './cloud-workflow.component';

describe('CloudWorkflowComponent', () => {
  let component: CloudWorkflowComponent;
  let fixture: ComponentFixture<CloudWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloudWorkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloudWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

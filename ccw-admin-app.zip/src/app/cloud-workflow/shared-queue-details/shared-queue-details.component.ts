import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-queue-details',
  templateUrl: './shared-queue-details.component.html',
  styleUrls: ['./shared-queue-details.component.scss']
})
export class SharedQueueDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

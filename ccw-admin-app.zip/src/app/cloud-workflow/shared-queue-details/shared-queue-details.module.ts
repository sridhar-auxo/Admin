import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedQueueDetailsComponent } from './shared-queue-details.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SharedQueueDetailsComponent]
})
export class SharedQueueDetailsModule { }

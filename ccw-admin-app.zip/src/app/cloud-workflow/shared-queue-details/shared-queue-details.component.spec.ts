import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedQueueDetailsComponent } from './shared-queue-details.component';

describe('SharedQueueDetailsComponent', () => {
  let component: SharedQueueDetailsComponent;
  let fixture: ComponentFixture<SharedQueueDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedQueueDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedQueueDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

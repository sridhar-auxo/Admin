import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloudCaptureComponent } from './cloud-capture.component';

describe('CloudCaptureComponent', () => {
  let component: CloudCaptureComponent;
  let fixture: ComponentFixture<CloudCaptureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloudCaptureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloudCaptureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

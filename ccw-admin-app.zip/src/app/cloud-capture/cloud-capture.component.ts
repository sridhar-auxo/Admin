import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-capture',
  templateUrl: './cloud-capture.component.html',
  styleUrls: ['./cloud-capture.component.scss']
})
export class CloudCaptureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

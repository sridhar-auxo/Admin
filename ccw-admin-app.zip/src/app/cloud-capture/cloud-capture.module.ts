import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CloudCaptureComponent } from './cloud-capture.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CloudCaptureComponent]
})
export class CloudCaptureModule { }
